#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout<<"Lets Start our Coding Journey, Jai Ganesh! ";
}